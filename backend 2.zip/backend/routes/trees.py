#os.path.expanduser("~")/mapem/backend/routes/trees.py
from flask import Blueprint, jsonify, current_app as app, request
from sqlalchemy import func
from backend.utils.helpers import get_db_connection
from flask import current_app as app  # Add at top if not there
from backend.models import TreeVersion, Individual, Family  # add to imports
import json
from backend.services.query_builders import build_event_query  # ⬅️ make sure this is at top
# top of backend/routes/trees.py
from backend.models import (
    TreeVersion, Individual, Family, Event   #  ← add Event here
)




tree_routes = Blueprint("trees", __name__, url_prefix="/api/trees")

@tree_routes.route("/", methods=["GET"], strict_slashes=False)
def list_trees():
    session = get_db_connection()
    try:
        subquery = session.query(
            TreeVersion.tree_name,
            func.max(TreeVersion.id).label("max_id")
        ).group_by(TreeVersion.tree_name).subquery()

        latest_versions = session.query(TreeVersion).join(
            subquery, TreeVersion.id == subquery.c.max_id
        ).order_by(TreeVersion.created_at.desc()).all()

        tree_list = [{
            "id": t.id,
            "name": t.tree_name,
            "uploaded_tree_id": t.uploaded_tree_id
        } for t in latest_versions]

        return jsonify(tree_list), 200

    except Exception as e:
        import traceback
        print("🔥 /api/trees failed")
        print(traceback.format_exc())
        return jsonify({"error": str(e)}), 500

    finally:
        session.close()


@tree_routes.route("/<int:tree_id>", methods=["GET"])
def get_tree(tree_id):
    session = get_db_connection()
    try:
        tree = session.query(TreeVersion).filter(TreeVersion.id == tree_id).first()
        if not tree:
            return jsonify({"error": "Tree not found"}), 404
        return jsonify({
            "id": tree.uploaded_tree_id,  # 👈 send uploaded ID here
            "name": tree.tree_name,
            "created_at": tree.created_at.isoformat() if tree.created_at else None
        }), 200
    except Exception as e:
        import traceback
        print("🔥 Error in /api/trees/<id>")
        print(traceback.format_exc())
        return jsonify({"error": str(e)}), 500
    finally:
        session.close()

# ────────────────────────────────────────────────────────────────
# 📊  Counts & Visible-Counts Endpoints
# ────────────────────────────────────────────────────────────────

@tree_routes.route("/<int:tree_id>/counts", methods=["GET"])
def tree_counts(tree_id):
    """Return total people & families in the tree (unfiltered)."""
    session = get_db_connection()
    try:
        total_people = session.query(Individual).filter_by(tree_id=tree_id).count()
        total_families = session.query(Family).filter_by(tree_id=tree_id).count()
        return jsonify({
            "totalPeople": total_people,
            "totalFamilies": total_families
        }), 200
    except Exception as e:
        app.logger.exception("🔥 /counts failed")
        return jsonify({"error": str(e)}), 500
    finally:
        session.close()

@tree_routes.route("/<int:tree_id>/visible-counts", methods=["GET"])
def visible_counts(tree_id):
    session = get_db_connection()
    try:
        filters = json.loads(request.args.get("filters", "{}") or "{}")
        print("📦 Filters received:", filters)
        ev_q    = build_event_query(session, tree_id, filters)

        # Get distinct individual and family IDs
        ind_ids = {row[0] for row in ev_q.with_entities(Event.individual_id).all() if row[0]}
        fam_ids = {row[0] for row in ev_q.with_entities(Event.family_id).all()     if row[0]}

        return jsonify({
            "people":   len(ind_ids),
            "families": len(fam_ids)
        }), 200

    except Exception as e:
        app.logger.exception("🔥 visible-counts failed")
        return jsonify({"people": 0, "families": 0, "error": str(e)}), 200
    finally:
        session.close()
