import React from "react";
import PeopleViewer from "../components/PeopleViewer";

export default function People() {
  return <PeopleViewer />;
}
