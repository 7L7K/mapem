import React from "react";
import { SearchProvider } from "./context/SearchContext";
import { TreeProvider } from "./context/TreeContext";
import { UploadStatusProvider } from "./components/UploadStatusContext";

export default function Providers({ children }) {
  return (
    <UploadStatusProvider>
      <TreeProvider>
        <SearchProvider>
          {children}
        </SearchProvider>
      </TreeProvider>
    </UploadStatusProvider>
  );
}
