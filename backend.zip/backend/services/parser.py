from datetime import datetime
from .gedcom_core import GedcomCoreParser
from .gedcom_normalizer import (
    normalize_individual,
    normalize_family,
    extract_events_from_individual,
    extract_events_from_family,
    parse_date_flexible,
)
from ..models import Individual, Family, TreeRelationship, Event, Location
from backend.utils.helpers import normalize_location_name
from sqlalchemy.orm import Session
import logging

logger = logging.getLogger(__name__)

# Tag → category map
TAG_CATEGORY_MAP = {
    "BIRT": "life_event",
    "DEAT": "life_event",
    "MARR": "life_event",
    "DIV":  "life_event",
    "RESI": "migration",
    "IMMI": "migration",
    "EMIG": "migration",
    "CENS": "migration",
    # ... etc
}

class GEDCOMParser:
    def __init__(self, file_path):
        self.file_path = file_path
        self.data = {}
        self.event_quality_counts = {}

    def parse_file(self):
        core = GedcomCoreParser(self.file_path)
        raw = core.parse()

        individuals, families, events = [], [], []

        # Process Individuals + their events
        for raw_ind in raw["individuals"]:
            norm = normalize_individual(raw_ind)
            individuals.append(norm)

            evts = extract_events_from_individual(raw_ind, norm)
            for evt in evts:
                tag = evt.get("source_tag", "").upper()
                # Provide a default if tag is missing
                evt["category"] = TAG_CATEGORY_MAP.get(tag, "unspecified")
            events.extend(evts)

        # Process Families + their events
        for raw_fam in raw["families"]:
            fam_norm = normalize_family(raw_fam)
            families.append(fam_norm)

            fam_evts = extract_events_from_family(raw_fam, fam_norm)
            for evt in fam_evts:
                tag = evt.get("source_tag", "").upper()
                evt["category"] = TAG_CATEGORY_MAP.get(tag, "unspecified")
            events.extend(fam_evts)

        self.data = {
            "individuals": individuals,
            "families": families,
            "events": events,
        }
        return self.data

    def save_to_db(self, session: Session, tree_id: int, geocode_client=None, dry_run=False):
        """
        Inserts Individuals, Families, Relationships, and Events.
        If a geocode_client is provided, any evt["location"] will be geocoded & linked.
        Supports a dry_run mode to rollback changes after processing.
        """
        data = self.data
        summary = {"people_count": 0, "event_count": 0, "warnings": [], "errors": []}

        # 1) Process Individuals
        for ind in data["individuals"]:
            gedcom_id = ind.get("gedcom_id")
            # Skip if name is missing because 'name' is NOT NULL in the DB
            if not ind.get("name"):
                logger.warning(f"⚠️ Skipping individual with missing name: {gedcom_id}")
                summary["warnings"].append(f"Missing name for individual {gedcom_id}")
                continue

            existing = session.query(Individual).filter_by(gedcom_id=gedcom_id, tree_id=tree_id).first()
            if existing:
                existing.name = ind.get("name")
                existing.occupation = ind.get("occupation")
                existing.notes = ind.get("notes")
            else:
                person = Individual(
                    gedcom_id=gedcom_id,
                    name=ind.get("name", "Unknown"),
                    occupation=ind.get("occupation"),
                    notes=ind.get("notes"),
                    tree_id=tree_id
                )
                session.add(person)
                summary["people_count"] += 1
        try:
            session.flush()
        except Exception as e:
            logger.error(f"💥 Flush failed after inserting Individuals: {e}")
            summary["errors"].append("Flush error after individuals")
            if not dry_run:
                raise

        # Build GEDCOM → DB ID map for Individuals
        ged2db = {
            p.gedcom_id: p.id
            for p in session.query(Individual).filter_by(tree_id=tree_id)
        }

        # 2) Process Families & Relationships
        for fam in data["families"]:
            fam_id = fam.get("gedcom_id")
            raw_h, raw_w = fam.get("husband_id"), fam.get("wife_id")
            h_id, w_id = ged2db.get(raw_h), ged2db.get(raw_w)

            existing_fam = session.query(Family).filter_by(gedcom_id=fam_id, tree_id=tree_id).first()
            if existing_fam:
                existing_fam.husband_id = h_id
                existing_fam.wife_id = w_id
            else:
                f = Family(
                    gedcom_id=fam_id,
                    husband_id=h_id,
                    wife_id=w_id,
                    tree_id=tree_id
                )
                session.add(f)
            # Create parent-child relationships
            for child_ged in fam.get("children", []):
                child_db = ged2db.get(child_ged)
                if h_id is not None and child_db is not None:
                    session.add(TreeRelationship(
                        tree_id=tree_id,
                        person_id=h_id,
                        related_person_id=child_db,
                        relationship_type="father"
                    ))
                if w_id is not None and child_db is not None:
                    session.add(TreeRelationship(
                        tree_id=tree_id,
                        person_id=w_id,
                        related_person_id=child_db,
                        relationship_type="mother"
                    ))
        try:
            session.flush()
        except Exception as e:
            logger.error(f"💥 Flush failed after inserting Families/Relationships: {e}")
            summary["errors"].append("Flush error after families")
            if not dry_run:
                raise

        # 3) Process Events (with location extraction & geocoding)
        for evt in data["events"]:
            # Skip events missing a type (required field)
            if not evt.get("event_type"):
                logger.warning(f"⚠️ Skipping event missing type: {evt}")
                summary["warnings"].append("Missing event_type in an event")
                continue

            dt = parse_date_flexible(evt.get("date")) if evt.get("date") else None
            e = Event(
                event_type=evt.get("event_type", "UNKNOWN"),
                date=dt,
                date_precision=evt.get("date_precision"),
                notes=evt.get("notes"),
                source_tag=evt.get("source_tag"),
                category=evt.get("category", "unspecified"),
                tree_id=tree_id
            )
            # Link to individual or family if applicable
            if evt.get("individual_gedcom_id"):
                e.individual_id = ged2db.get(evt["individual_gedcom_id"])
            if evt.get("family_gedcom_id"):
                # Optionally handle family events if you build fam2db mapping
                pass

            # LOCATION HANDLING
            place = evt.get("location") or evt.get("place")
            if place and geocode_client:
                try:
                    lat, lon, norm_name, conf = geocode_client.get_or_create_location(session, place)
                    # Check if location already exists
                    loc = session.query(Location).filter_by(normalized_name=norm_name).first()
                    if not loc:
                        loc = Location(
                            name=place,
                            normalized_name=norm_name,
                            latitude=lat,
                            longitude=lon,
                            confidence_score=conf
                        )
                        session.add(loc)
                        try:
                            session.flush()
                        except Exception as ex:
                            logger.warning(f"⚠️ Flush failed after inserting location '{place}': {ex}")
                            summary["warnings"].append(f"Flush error for location '{place}'")
                    e.location_id = loc.id
                    logger.debug(f"📍 Linked event to location: {place} → ID {loc.id}")
                except Exception as ex:
                    logger.warning(f"⚠️ Failed to link location '{place}': {ex}")
                    summary["warnings"].append(f"Location failed for '{place}'")
            elif place:
                # Fallback if geocode_client is missing
                norm_name = normalize_location_name(place)
                loc = session.query(Location).filter_by(normalized_name=norm_name).first()
                if not loc:
                    loc = Location(name=place, normalized_name=norm_name)
                    session.add(loc)
                    try:
                        session.flush()
                    except Exception as ex:
                        logger.warning(f"⚠️ Flush failed for non-geocoded location '{place}': {ex}")
                        summary["warnings"].append(f"Flush error for non-geocoded location '{place}'")
                e.location_id = loc.id
                logger.debug(f"📍 Linked (non-geocoded) location: {place} → ID {loc.id}")

            # **CRITICAL:** Add the event to the session!
            session.add(e)
            summary["event_count"] += 1
        try:
            session.flush()
        except Exception as e:
            logger.error(f"💥 Flush failed after inserting Events: {e}")
            summary["errors"].append("Flush error after events")
            if not dry_run:
                raise

        # Final summary logs before commit
        print("📊 Insert Summary:")
        print("👤 Individuals added:", summary["people_count"])
        print("📅 Events added:", summary["event_count"])
        print("⚠️ Warnings:", len(summary["warnings"]))

        if dry_run:
            session.rollback()
            logger.info("🧪 Dry run mode enabled: transaction rolled back.")
        return summary
