#!/usr/bin/env python
# ─────────────────────────────────────────────────────────────────────────────
# 📍 Geocode Service (v2) — MapEm
# /backend/services/geocode.py
# -----------------------------------------------------------------------------
# ✨ This is v2 of the geocoding engine for the MapEm project. Replaces the
# original v1 which returned inconsistent tuple formats and allowed NULL values.
#
# ✅ Improvements over v1:
#  1. Always returns a structured dict with:
#       raw_name, name, normalized_name, latitude, longitude, confidence_score,
#       timestamp, status, source, and historical_data.
#  2. Prevents null violations by ensuring raw_name is always populated.
#  3. Uses proper logging (debug/info/warning/error) instead of print().
#  4. Normalizes cache keys to avoid duplicates.
#  5. Optional cache support and the ability to disable via use_cache=False.
#  6. Implements retry/backoff logic for API calls (Google/Nominatim).
#  7. Provides a CLI test mode to run a quick geocode (e.g., python geocode.py "Place, USA").
#  8. Planned Historical Lookups: checks a manual override JSON and static historical data.
#
# 🔥 Designed to plug cleanly into your GEDCOMParser pipeline via:
#       loc_data = geocoder.get_or_create_location(session, place_str)
#       location = Location(**loc_data)
#
# ─────────────────────────────────────────────────────────────────────────────
import os
import json
import time
import requests
import logging
from datetime import datetime
from urllib.parse import urlencode
from backend import models
from backend.utils.helpers import normalize_location_name, calculate_name_similarity

logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)

# Load manual overrides from JSON (if available)
MANUAL_FIXES_FILE = os.path.join(os.path.dirname(__file__), "..", "data", "manual_place_fixes.json")
if os.path.exists(MANUAL_FIXES_FILE):
    with open(MANUAL_FIXES_FILE, "r") as f:
        try:
            manual_fixes = json.load(f)
        except Exception:
            manual_fixes = {}
else:
    manual_fixes = {}

# Placeholder for historical places
# You might have static files in data/historical_places/ — load them as needed
historical_lookup = {}
# Example: historical_lookup["sunflower:beat 2"] = { "modern_equivalent": "Ruleville, MS, USA", "lat":33.7879, "lng": -90.5764, "year_range": "1900-1930" }

print(f"🛠️ Loaded geocode.py from: {__file__}")

class Geocode:
    def __init__(self, api_key=None, cache_file='geocode_cache.json', use_cache=True):
        self.api_key = api_key
        self.cache_file = cache_file
        self.cache_enabled = use_cache
        self.cache = self._load_cache() if use_cache else {}

    def _load_cache(self):
        if os.path.exists(self.cache_file):
            try:
                with open(self.cache_file, 'r') as f:
                    return json.load(f)
            except json.JSONDecodeError:
                logger.warning("⚠️ Cache file corrupted, starting fresh.")
                return {}
        return {}

    def _save_cache(self):
        if self.cache_enabled:
            with open(self.cache_file, 'w') as f:
                json.dump(self.cache, f, indent=2)

    def _normalize_key(self, place):
        return normalize_location_name(place.strip()).lower()

    def _retry_request(self, func, *args, retries=2, backoff=1, **kwargs):
        for attempt in range(1, retries + 1):
            try:
                return func(*args, **kwargs)
            except requests.RequestException as e:
                logger.warning(f"⚠️ Request failed (attempt {attempt}/{retries}): {e}")
                time.sleep(backoff * attempt)
        return None

    def _google_geocode(self, location):
        base_url = "https://maps.googleapis.com/maps/api/geocode/json"
        params = {"address": location, "key": self.api_key}
        url = f"{base_url}?{urlencode(params)}"
        def call():
            return requests.get(url, timeout=5)
        resp = self._retry_request(call)
        if not resp or resp.status_code != 200:
            logger.error(f"❌ Google geocode error: status {resp.status_code if resp else 'no response'}")
            return None, None, None, None
        data = resp.json()
        if not data.get('results'):
            return None, None, None, None
        result = data['results'][0]
        loc = result['geometry']['location']
        location_type = result['geometry'].get('location_type', '')
        confidence = 1.0 if location_type.upper() == "ROOFTOP" else 0.75
        normalized_name = result.get('formatted_address', location)
        return loc['lat'], loc['lng'], normalized_name, confidence

    def _nominatim_geocode(self, location):
        base_url = "https://nominatim.openstreetmap.org/search"
        headers = {"User-Agent": "GenealogyMapper"}
        params = {"q": location, "format": "json", "limit": 1}
        def call(p):
            return requests.get(base_url, params=p, headers=headers, timeout=10)
        resp = self._retry_request(call, params)
        if resp and resp.status_code == 200:
            data = resp.json()
            if data:
                lat = float(data[0]['lat'])
                lon = float(data[0]['lon'])
                name = data[0]['display_name']
                return lat, lon, name, 0.8
        # Fallback: try only the city part
        city = location.split(",")[0].strip()
        logger.info(f"🪃 Falling back to city-only geocode: '{city}'")
        params["q"] = city
        resp = self._retry_request(call, params)
        if resp and resp.status_code == 200:
            data = resp.json()
            if data:
                lat = float(data[0]['lat'])
                lon = float(data[0]['lon'])
                name = data[0]['display_name']
                return lat, lon, name, 0.7
        return None, None, None, None

    def preload_cache(self, place_list):
        """Bulk-geocode a list of places to warm the cache."""
        for place in set(place_list):
            key = self._normalize_key(place)
            if key in self.cache:
                continue
            logger.info(f"🔄 Preloading geocode for '{place}'")
            lat, lng, norm, conf = (
                self._google_geocode(place) if self.api_key
                else self._nominatim_geocode(place)
            )
            if lat is not None:
                self.cache[key] = (lat, lng, norm, conf)
        self._save_cache()

    def get_or_create_location(self, session, location_name):
        """
        Returns a structured dict with keys:
          raw_name, name, normalized_name, latitude, longitude, confidence_score,
          timestamp, status, source, historical_data.
          
        Also logs unresolved locations for manual review.
        """
        logger.debug(f"Geocode called with place='{location_name}'")
        if not location_name:
            logger.warning("⚠️ Empty location_name provided.")
            return None

        # Normalize input
        raw_name = location_name.strip().replace(",,", ",").replace("  ", " ")
        key = self._normalize_key(raw_name)

        # Check manual fixes first
        if raw_name in manual_fixes:
            logger.info(f"✅ Manual override for '{raw_name}'")
            override = manual_fixes[raw_name]
            return {
                "raw_name": raw_name,
                "name": override.get("modern_equivalent", raw_name),
                "normalized_name": override.get("modern_equivalent", raw_name),
                "latitude": override.get("lat"),
                "longitude": override.get("lng"),
                "confidence_score": 1.0,
                "timestamp": datetime.utcnow(),
                "status": "manual",
                "source": "manual",
                "historical_data": {}
            }
        
        # Check historical lookup if applicable (using loaded historical_lookup dict)
        hist_key = f"sunflower:{raw_name.lower()}"  # adjust per your design
        if hist_key in historical_lookup:
            hp = historical_lookup[hist_key]
            logger.info(f"✅ Historical match for '{raw_name}'")
            return {
                "raw_name": raw_name,
                "name": hp.get("modern_equivalent", raw_name),
                "normalized_name": hp.get("modern_equivalent", raw_name),
                "latitude": hp.get("lat"),
                "longitude": hp.get("lng"),
                "confidence_score": 1.0,
                "timestamp": datetime.utcnow(),
                "status": "historical",
                "source": "historical",
                "historical_data": {"year_range": hp.get("year_range")}
            }
        
        # If location is generic and before 1890, mark as vague (example threshold)
        # You can incorporate additional logic if you have event date context
        if raw_name.lower() in {"mississippi", "usa", "unknown"}:
            logger.info(f"🚫 Vague location accepted for '{raw_name}'")
            return {
                "raw_name": raw_name,
                "name": raw_name,
                "normalized_name": raw_name,
                "latitude": None,
                "longitude": None,
                "confidence_score": 0.0,
                "timestamp": datetime.utcnow(),
                "status": "vague",
                "source": "none",
                "historical_data": {}
            }

        # Check cache
        if self.cache_enabled and key in self.cache:
            logger.info(f"⚡ Cache hit for '{raw_name}'")
            lat, lng, norm, conf = self.cache[key]
            status = "ok"
            source = "cache"
        else:
            # Fuzzy DB match
            found = None
            for loc in session.query(models.Location).all():
                sim = calculate_name_similarity(loc.name, raw_name)
                logger.debug(f"🧪 Similarity between '{loc.name}' and '{raw_name}' = {sim}")
                if sim >= 90:
                    logger.info(f"✅ DB match found for '{raw_name}' as '{loc.name}'")
                    found = {
                        "raw_name": raw_name,
                        "name": loc.name,
                        "normalized_name": loc.normalized_name,
                        "latitude": loc.latitude,
                        "longitude": loc.longitude,
                        "confidence_score": loc.confidence_score,
                        "timestamp": datetime.utcnow(),
                        "status": "ok",
                        "source": "db",
                        "historical_data": loc.historical_data or {}
                    }
                    break
            if found:
                return found

            # External geocode fallback
            logger.info(f"🌐 Falling back to external geocode for '{raw_name}'")
            if self.api_key:
                lat, lng, norm, conf = self._google_geocode(raw_name)
                source = "google"
            else:
                lat, lng, norm, conf = self._nominatim_geocode(raw_name)
                source = "nominatim"
            if lat is None or lng is None:
                logger.warning(f"❌ Geocoding failed for '{raw_name}'")
                # Log unresolved location to a shared file for future review
                unresolved_file = os.path.join(os.path.dirname(__file__), "..", "data", "unresolved_locations.json")
                unresolved = []
                if os.path.exists(unresolved_file):
                    try:
                        with open(unresolved_file, "r") as uf:
                            unresolved = json.load(uf)
                    except Exception:
                        unresolved = []
                unresolved.append({
                    "raw_name": raw_name,
                    "source_tag": "unknown",
                    "timestamp": datetime.utcnow().isoformat(),
                    "reason": "geocode_failed"
                })
                with open(unresolved_file, "w") as uf:
                    json.dump(unresolved, uf, indent=2)
                return {
                    "raw_name": raw_name,
                    "name": raw_name,
                    "normalized_name": raw_name,
                    "latitude": None,
                    "longitude": None,
                    "confidence_score": 0._
