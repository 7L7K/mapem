import React from "react";
import { Routes, Route, Navigate } from "react-router-dom";
import Layout from "./components/Layout";

// Pages
import Dashboard from "./components/Dashboard";
import MapPage from "./pages/MapPage";
import People from "./pages/People";
import Timeline from "./pages/Timeline";
import UploadPage from "./pages/UploadPage";

export default function App() {
  return (
    <Routes>
      <Route element={<Layout />}>
        <Route path="/" element={<Navigate to="/dashboard" />} />
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/map" element={<MapPage />} />
        <Route path="/timeline" element={<Timeline />} />
        <Route path="/people" element={<People />} />
        <Route path="/upload" element={<UploadPage />} />
      </Route>
    </Routes>
  );
}
