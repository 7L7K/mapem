// frontend/src/shared/components/MapHUD/FloatingFilterPill.jsx
import React from "react";
import { useSearch } from "@shared/context/SearchContext";

export default function FloatingFilterPill() {
  const { setIsDrawerOpen } = useSearch();

  return (
    <div className="fixed top-4 right-6 z-40">
      <button
        onClick={() => setIsDrawerOpen(true)}
        className="bg-[var(--surface)] text-[var(--text)] px-4 py-2 rounded-full shadow hover:bg-white/10 transition"
      >
        ⚙️ Filters
      </button>
    </div>
  );
}
