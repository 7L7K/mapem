// src/shared/components/dev/RenderStatus.jsx
import React from "react";

/**
 * A floating debug panel that shows key values and component state info.
 * Ideal for development and quick diagnostics.
 *
 * @param {Object} props
 * @param {Object} props.info - A dictionary of key-value pairs to display.
 */
export default function RenderStatus({ info = {} }) {
  return (
    <div className="fixed bottom-4 right-4 z-[999] w-72 bg-black/75 text-white text-xs rounded-xl shadow-xl backdrop-blur-md px-4 py-3 space-y-1 border border-white/10 font-mono">
      <div className="text-accent font-bold text-sm pb-1 border-b border-white/10">🩺 RenderStatus</div>
      {Object.entries(info).map(([key, val]) => (
        <div key={key} className="flex justify-between items-center">
          <span className="text-gray-300">{key}</span>
          <span className="text-white max-w-[10rem] truncate text-right">{String(val)}</span>
        </div>
      ))}
      <div className="pt-2 text-right text-gray-400 text-[10px] italic">
        {new Date().toLocaleTimeString()}
      </div>
    </div>
  );
}
