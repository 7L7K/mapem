// src/components/ui/Loader.jsx
import React from 'react';

const Loader = () => <div className="loader">Loading...</div>;

export default Loader;
