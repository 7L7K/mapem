// src/context/SearchContext.jsx
import React, { createContext, useContext, useState } from "react";

const SearchContext = createContext();

export function SearchProvider({ children }) {
  const [query, setQuery] = useState("");
  const [mode, setMode] = useState("person"); // or 'family', etc.
  const [showFilters, setShowFilters] = useState(false);

  const toggleFilters = () => setShowFilters(prev => !prev);

  return (
    <SearchContext.Provider
      value={{
        query,
        setQuery,
        mode,
        setMode,
        showFilters,
        toggleFilters,
      }}
    >
      {children}
    </SearchContext.Provider>
  );
}

export function useSearch() {
  return useContext(SearchContext);
}
